package conjugaison;

public enum Temps {
	Indicatif_pr�sent,
	Indicatif_imparfait,
	Indicatif_pass�_simple,
	Indicatif_futur_simple,
	Conditionnel_pr�sent,
	Subjonctif_pr�sent,
	Subjonctif_imparfait,
	Imp�ratif_pr�sent,
	Participe_pr�sent,
	Participe_pass�,
	Infinitif_pr�sent, 
	G�rondif
}
