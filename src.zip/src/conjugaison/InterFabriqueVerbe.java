package conjugaison;

public interface InterFabriqueVerbe {
	Verbe getVerbe(String v);
}
