package conjugaison;

public interface InterFabriqueVerbe {
	InterVerbe getVerbe(String v);
}
