package conjugaison;

import java.util.ArrayList;

public interface InterVerbe {
	public ArrayList<String> conjuguer();
	
	public String getRadical();
	
	public String getTerminaison();
	
	public String getPronominal();
	
}
