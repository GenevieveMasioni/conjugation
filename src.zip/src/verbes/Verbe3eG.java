package verbes;

import java.util.ArrayList;

public class Verbe3eG extends Verbe {
	
	public Verbe3eG(String vb, boolean vp, String[] af) {
		super(vb, vp, af);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public ArrayList<String> conjuguer() {
		// TODO Auto-generated method stub
		return null;
	}

}
