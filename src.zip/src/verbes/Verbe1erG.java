package verbes;

public class Verbe1erG extends Verbe {

	public Verbe1erG(String vb, boolean vp, String[] af) {
		super(vb, vp, af);
	}

}
