package verbes;

public class Verbe2eG extends Verbe {
	
	public Verbe2eG(String vb, boolean vp, String[] af) {
		super(vb, vp, af);
	}

}
